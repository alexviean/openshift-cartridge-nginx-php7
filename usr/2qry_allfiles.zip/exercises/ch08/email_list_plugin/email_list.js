$(document).ready(function() {
	$("#email").focus();
	
}); // end ready
